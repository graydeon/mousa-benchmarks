set -euo pipefail
export CGO_ENABLED=0 GOAMD64=v1 GOMAXPROCS=6
input="$OMP_INPUT/diagnostic"
go version > "$OMP_OUTPUT/toolchain.txt"
go env -json > "$OMP_OUTPUT/go-env.json"
uname -a > "$OMP_OUTPUT/kernel.txt"
cp "$input/old-baseline" "$input/old-candidate" "$OMP_OUTPUT/"
chmod +x "$OMP_OUTPUT/old-baseline" "$OMP_OUTPUT/old-candidate"
base=$(mktemp -d)
candidate=$(mktemp -d)
tar -xf "$input/baseline.tar" -C "$base"
cp -a "$base/." "$candidate/"
cd "$candidate"
git apply "$input/candidate.patch"
for arm in baseline candidate; do
  source="$base"
  if [ "$arm" = candidate ]; then source="$candidate"; fi
  cd "$source"
  python3 - "$OMP_OUTPUT/$arm-source.json" <<'PY'
import hashlib,json,sys
from pathlib import Path
Path(sys.argv[1]).write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path('.').rglob('*')) if p.is_file()},indent=2)+'\n')
PY
  go build -trimpath -buildvcs=false -o "$OMP_OUTPUT/$arm" ./cmd/mousa
  go version -m "$OMP_OUTPUT/$arm" > "$OMP_OUTPUT/$arm-build.txt"
  copy=$(mktemp -d)
  cp -a "$source/." "$copy/"
  python3 "$input/instrument.py" "$copy"
  cd "$copy"
  gofmt -w internal/packingdiag internal/sqlite internal/mousa/trail.go cmd/mousa
  go build -trimpath -buildvcs=false -o "$OMP_OUTPUT/stage-$arm" ./cmd/mousa
  echo "Built $arm and separate stage binary"
done
python3 "$input/run.py"
