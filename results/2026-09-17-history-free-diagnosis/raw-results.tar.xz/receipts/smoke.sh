set -euo pipefail
cp "$OMP_INPUT/diagnostic/old-baseline" "$OMP_INPUT/diagnostic/old-candidate" "$OMP_INPUT/diagnostic/baseline" "$OMP_INPUT/diagnostic/candidate" "$OMP_OUTPUT/"
chmod +x "$OMP_OUTPUT/old-baseline" "$OMP_OUTPUT/old-candidate" "$OMP_OUTPUT/baseline" "$OMP_OUTPUT/candidate"
python3 "$OMP_INPUT/diagnostic/run.py" --smoke-only
