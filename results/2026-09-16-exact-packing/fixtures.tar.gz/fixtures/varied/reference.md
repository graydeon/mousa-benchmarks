# Storage classes

| Class | Retention | Copies |
|---|---|---|
| Bronze | 7 days | 1 |
| Silver | 30 days | 2 |

- Bronze is for temporary staging.
- Silver is for reviewed records.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

