# Amber restart

To restart Amber safely, run both commands in order:

```sh
service amber stop
service amber start
```

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

Background: this section describes ordinary unrelated material for the fixture.

