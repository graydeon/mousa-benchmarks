set -euo pipefail
export CGO_ENABLED=0 GOAMD64=v1 GOMAXPROCS=6
python3 - "$PWD" "$OMP_OUTPUT/source-manifest.json" <<'PY'
import hashlib,json,sys
from pathlib import Path
p=Path(sys.argv[1]); files=sorted(x for x in p.rglob('*') if x.is_file() and '.git' not in x.parts)
Path(sys.argv[2]).write_text(json.dumps({str(x.relative_to(p)):hashlib.sha256(x.read_bytes()).hexdigest() for x in files},indent=2)+'\n')
PY
go test ./internal/sqlite -run 'Test(HistoricalVerification|ExactTrail|SourceTrail)' -count=1 -v > "$OMP_OUTPUT/focused.log" 2>&1
echo 0 > "$OMP_OUTPUT/focused.exit"
go build -o "$OMP_OUTPUT/candidate" ./cmd/mousa
candidate_source="$PWD"
base=$(mktemp -d)
tar -xf "$OMP_INPUT/baseline/baseline.tar" -C "$base"
cd "$base"
go build -o "$OMP_OUTPUT/baseline" ./cmd/mousa
for arm in baseline candidate; do
  source="$base"
  if [ "$arm" = candidate ]; then source="$candidate_source"; fi
  for kind in stage allocation; do
    copy=$(mktemp -d)
    cp -a "$source/." "$copy/"
    if [ "$kind" = allocation ]; then
      python3 "$OMP_INPUT/run/instrument.py" "$copy" allocations
    else
      python3 "$OMP_INPUT/run/instrument.py" "$copy"
    fi
    cd "$copy"
    gofmt -w internal/packingdiag internal/sqlite internal/mousa/trail.go cmd/mousa
    go build -o "$OMP_OUTPUT/$kind-$arm" ./cmd/mousa
  done
done
python3 "$OMP_INPUT/run/compare.py"
