set -euo pipefail
export CGO_ENABLED=0 GOAMD64=v1 GOMAXPROCS=6
mkdir -p cmd/historydiag
cp "$OMP_INPUT/run/history.go" cmd/historydiag/main.go
go build -o "$OMP_OUTPUT/history" ./cmd/historydiag
go build -o "$OMP_OUTPUT/baseline" ./cmd/mousa
python3 "$OMP_INPUT/run/instrument.py" "$PWD"
gofmt -w internal/packingdiag internal/sqlite internal/mousa/trail.go cmd/mousa
go build -o "$OMP_OUTPUT/diagnostic" ./cmd/mousa
python3 "$OMP_INPUT/run/diagnostic.py"
go tool pprof -top "$OMP_OUTPUT/diagnostic" "$OMP_OUTPUT/cpu.pprof" > "$OMP_OUTPUT/cpu-top.txt"
go tool pprof -top -cum "$OMP_OUTPUT/diagnostic" "$OMP_OUTPUT/cpu.pprof" > "$OMP_OUTPUT/cpu-cumulative.txt"
