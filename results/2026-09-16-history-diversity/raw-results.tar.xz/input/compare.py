import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import time

out=Path(os.environ['OMP_OUTPUT'])
inputs=Path(os.environ['OMP_INPUT'])
seeds=inputs/'seeds'
protocol=inputs/'run/comparison-protocol.json'
rows_path=out/'comparison.jsonl'
keys=['evidence','packet_id','used_bytes','budget_bytes','budget_omitted','matched_candidates','lifecycle_excluded','expression','duplicate_omitted','packing_policy','outcome','candidate_limit','query_policy','decision_outcome','decision_reasons']
observations=[]
request_ids=set()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def call(arm, fixture, history, policy, repetition, kind):
    seed=seeds/f'{fixture}-{history}.sqlite'
    work=out/'work.sqlite'
    assert not work.exists()
    shutil.copyfile(seed,work)
    assert sha(work)==sha(seed)
    binary=out/(arm if kind in ('warmup','wall') else kind+'-'+arm)
    cost=out/'cost.txt'
    command=['/usr/bin/time','-f','%M %U %S','-o',str(cost),str(binary),'-store',str(work),'query','--source','scaling','--packing-policy',policy,'--budget-bytes','8192','amber']
    start=time.perf_counter_ns()
    proc=subprocess.run(command,capture_output=True,timeout=120)
    row=dict(arm=arm,fixture=fixture,history=history,policy=policy,repetition=repetition,kind=kind,command=command,exit=proc.returncode,wall_ms=(time.perf_counter_ns()-start)/1e6,stdout=proc.stdout.decode(),stderr=proc.stderr.decode())
    with (out/'attempts.jsonl').open('a') as f: f.write(json.dumps(row)+'\n')
    assert proc.returncode==0,row
    response=json.loads(row.pop('stdout'))
    assert response['request_id'] not in request_ids
    request_ids.add(response['request_id'])
    row['response']=response
    rss,user,system=cost.read_text().split()
    row.update(rss_kib=int(rss),user_s=float(user),system_s=float(system))
    if kind in ('stage','allocation'): row['diagnostic']=json.loads(row.pop('stderr'))
    else: assert not row.pop('stderr')
    with rows_path.open('a') as f: f.write(json.dumps(row)+'\n')
    observations.append(row)
    work.unlink()
    assert not any(Path(str(work)+suffix).exists() for suffix in ('-wal','-shm','-journal'))
    return {k:response.get(k) for k in keys}
for fixture in ('small','shared','diverse'):
 for history in (0,200):
  for policy in ('original','exact-v1'):
   oracle=None
   for kind,n in [('warmup',1),('wall',12),('stage',1),('allocation',1)]:
    for repetition in range(n):
     for arm in (('baseline','candidate') if repetition%2==0 else ('candidate','baseline')):
      result=call(arm,fixture,history,policy,repetition,kind)
      if oracle is None: oracle=result
      assert result==oracle,(fixture,history,policy,kind,arm)
summary=[]
for fixture in ('small','shared','diverse'):
 for history in (0,200):
  for policy in ('original','exact-v1'):
   cell=[r for r in observations if (r['fixture'],r['history'],r['policy'])==(fixture,history,policy)]
   arms={}
   for arm in ('baseline','candidate'):
    wall=[r for r in cell if r['arm']==arm and r['kind']=='wall']
    alloc=next(r['diagnostic']['allocated_bytes'] for r in cell if r['arm']==arm and r['kind']=='allocation')
    arms[arm]={'median_ms':statistics.median(r['wall_ms'] for r in wall),'max_ms':max(r['wall_ms'] for r in wall),'median_rss_kib':statistics.median(r['rss_kib'] for r in wall),'allocated_bytes':alloc}
   b,c=arms['baseline'],arms['candidate']
   ratio=c['median_ms']/b['median_ms']
   gates={'latency':ratio<=(0.85 if history==200 and fixture!='small' else 1.10),'tail':c['max_ms']<=b['max_ms']*1.25,'rss':c['median_rss_kib']<=b['median_rss_kib']+max(2048,b['median_rss_kib']*.15),'allocation':c['allocated_bytes']<=b['allocated_bytes']*1.10}
   summary.append(dict(fixture=fixture,history=history,policy=policy,arms=arms,latency_percent=(ratio-1)*100,gates=gates))
(out/'summary.json').write_text(json.dumps({'cells':summary,'pass':all(all(r['gates'].values()) for r in summary)},indent=2)+'\n')
(out/'measurement-manifest.json').write_text(json.dumps({'protocol_sha256':sha(protocol),'seeds':{p.name:sha(p) for p in sorted(seeds.glob('*.sqlite'))},'binaries':{n:sha(out/n) for n in ('baseline','candidate','stage-baseline','stage-candidate','allocation-baseline','allocation-candidate')}},indent=2)+'\n')
print('Comparison complete; all observations retained; gates',all(all(r['gates'].values()) for r in summary))
