package main

import (
 "context"
 "fmt"
 "os"
 "strconv"
 "time"
 "github.com/graydeon/mousa/internal/mousa"
 "github.com/graydeon/mousa/internal/sqlite"
)

func main() {
 ctx, cancel := context.WithTimeout(context.Background(), 120*time.Second)
 defer cancel()
 store, err := sqlite.Open(ctx, os.Args[1]); if err != nil { panic(err) }; defer store.Close()
 source, err := mousa.ParseSourceID(os.Args[2]); if err != nil { panic(err) }
 n, err := strconv.Atoi(os.Args[3]); if err != nil { panic(err) }
 for i := range n {
  request := mousa.PolicyEvaluationRequest{Schema:mousa.PolicyEvaluationRequestSchema, Action:mousa.SourceRetrievalAction, CallerNamespace:"mousa-local.caller", ExternalCallerID:"cli", ExternalRequestID:fmt.Sprintf("history-%d",i), PurposeNamespace:"mousa-local.purpose", ExternalPurposeID:"retrieval", SourceID:source, RequestedAtUsec:int64(i+1)}
  request.ID,err=mousa.NewPolicyEvaluationRequestID(request); if err!=nil { panic(err) }
  policy:=mousa.PackingOriginal; if i%2==1 { policy=mousa.PackingExactV1 }
  result,err:=store.EvaluateAndTraceLexical(ctx,request,"amber",100,8192,policy); if err!=nil { panic(err) }
  if result.Decision.Outcome != mousa.PolicyOutcomeAllow || len(result.Trail.Candidates)==0 { panic("history must contain allowed candidates") }
 }
 fmt.Println("created",n,"trails")
}
