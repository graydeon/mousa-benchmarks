import argparse
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('--smoke', action='store_true')
a = p.parse_args()
out = Path(os.environ['OMP_OUTPUT'])
protocol = Path(os.environ['OMP_INPUT']) / 'run/protocol.json'
rows = out / 'observations.jsonl'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def call(args, label, payload=None, env=None):
    start = time.perf_counter_ns()
    r = subprocess.run(args, input=payload, capture_output=True, timeout=120, env=env)
    row = dict(label=label, command=list(map(str,args)), exit=r.returncode, wall_ms=(time.perf_counter_ns()-start)/1e6, stdout=r.stdout.decode(), stderr=r.stderr.decode())
    with rows.open('a') as f:
        f.write(json.dumps(row)+'\n')
    if r.returncode:
        raise RuntimeError(row)
    return r
manifest = {'protocol_sha256':sha(protocol), 'binaries':{n:sha(out/n) for n in ('baseline','diagnostic','history')}, 'fixtures':{}}
fixtures = ['small','diverse'] if a.smoke else ['small','shared','diverse']
for fixture in fixtures:
    count = 1 if fixture == 'small' else 32
    pieces = [('amber %04d '%i).ljust(4096) for i in range(count)]
    texts = [''.join(pieces)] if fixture == 'shared' else pieces
    payload = ''.join(json.dumps({'id':f'doc-{i}.txt','text':text})+'\n' for i,text in enumerate(texts)).encode()
    (out/(fixture+'.jsonl')).write_bytes(payload)
    manifest['fixtures'][fixture] = hashlib.sha256(payload).hexdigest()
    seed = out/(fixture+'-0.sqlite')
    call([str(out/'baseline'),'-store',str(seed),'sync','--source','scaling','--segment-policy','fixed-v1'], fixture+' sync', payload)
    with closing(sqlite3.connect(seed)) as db:
        source = json.loads(db.execute('SELECT record_json FROM sources').fetchone()[0])['id']
        assert db.execute('SELECT count(*) FROM segments').fetchone()[0] == count
        assert db.execute('SELECT count(*) FROM representations').fetchone()[0] == len(texts)
    history = 2 if a.smoke else 200
    grown = out/(fixture+f'-{history}.sqlite')
    shutil.copyfile(seed,grown)
    call([str(out/'history'),str(grown),source,str(history)], fixture+' history')
    with closing(sqlite3.connect(grown)) as db:
        assert db.execute('SELECT count(*) FROM source_trails').fetchone()[0] == history
        assert dict(db.execute("SELECT json_extract(record_json,'$.schema'), count(*) FROM source_trails GROUP BY 1")) == {'mousa.source_trail.v1':history//2,'mousa.source_trail.v2':history//2}
    for size in (0,history):
        for policy in ('original','exact-v1'):
            work = out/'query.sqlite'
            shutil.copyfile(out/(fixture+f'-{size}.sqlite'),work)
            env = dict(os.environ)
            if not a.smoke and fixture=='diverse' and size==200 and policy=='exact-v1':
                env['PACKING_CPU_PROFILE']=str(out/'cpu.pprof')
            r = call([str(out/'diagnostic'),'-store',str(work),'query','--source','scaling','--packing-policy',policy,'--budget-bytes','8192','amber'], f'{fixture}/{size}/{policy}', env=env)
            result=json.loads(r.stdout)
            assert result['matched_candidates']==count and result['used_bytes']==min(count,2)*4096
            assert len(result['evidence'])==min(count,2)
            for hit in result['evidence']:
                i=int(hit['item'].removeprefix('doc-').removesuffix('.txt'))
                raw=texts[i].encode()
                assert hashlib.sha256(raw).hexdigest()==hit['representation_sha256']
                assert raw[hit['byte_start']:hit['byte_end']]==hit['text'].encode()
            json.loads(r.stderr)
            work.unlink()
    manifest[fixture+'_seeds']={str(n):sha(out/(fixture+f'-{n}.sqlite')) for n in (0,history)}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS schema, counts, coordinates, diagnostic output', fixtures)
