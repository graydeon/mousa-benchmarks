set -euo pipefail
export CGO_ENABLED=0 GOAMD64=v1 GOMAXPROCS=6
go build -o "$OMP_OUTPUT/mousa" ./cmd/mousa
python3 examples/docs/docs_test.py --mousa "$OMP_OUTPUT/mousa"
python3 examples/docs/evaluate.py --mousa "$OMP_OUTPUT/mousa" --output "$OMP_OUTPUT/consumer.json"
